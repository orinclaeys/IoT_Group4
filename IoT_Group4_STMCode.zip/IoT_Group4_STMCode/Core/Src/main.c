/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdbool.h>
#include <string.h>
#include "SHT40.h" // humidity & temperature sensor
#include "LTR329.h" // light sensor
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
union msg_data_u {
    float temperature;
    float humidity;
    float light;
};

typedef struct {
    //const char start_msg_char;
    //enum msg_type_e msg_type;
    const char msg_type;
    uint8_t x;
    uint8_t y;
    union msg_data_u msg_data;
    const char end_msg_char;
} __attribute__((packed)) message;

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */
int Coordinaat[] = { 0, 0};
int direction[] = {0, 1} ;
int routeSize = 0;
typedef struct location{
    int x_co;
    int y_co;
};
struct location route[50];
/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
I2C_HandleTypeDef hi2c3;

UART_HandleTypeDef huart2;

/* USER CODE BEGIN PV */
uint8_t UART2_rxBuffer[4];
volatile bool rx_flag = RESET;
//volatile char send_type;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_I2C3_Init(void);
/* USER CODE BEGIN PFP */
uint8_t create_payload(message msg, uint8_t *payload);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
void SHT40_Init()
{
	HAL_I2C_Init(&hi2c3); // Initialize and configure the I2C peripheral
}
void SHT40_Read(float *t, float *rh, uint8_t mode)
{
	uint8_t data[2] = {mode, 0x00};
	uint8_t buffer[6];

    HAL_I2C_Master_Transmit(&hi2c3, SHT40_I2C_ADDRESS, data, 2, HAL_MAX_DELAY);
    HAL_Delay(10);
    HAL_I2C_Master_Receive(&hi2c3, SHT40_I2C_ADDRESS, buffer, 6, HAL_MAX_DELAY);

    uint16_t t_ticks = buffer[0]*256 + buffer[1];
    uint16_t checksum_t = buffer[2];
    uint16_t rh_ticks = buffer[3]*256 + buffer[4];
    uint16_t checksum_rh = buffer[5];

    float t_degC = -45 + 175.0 * t_ticks/65535;
    float rh_pRH = -6 + 125.0 * rh_ticks/65535;

    if (rh_pRH > 100){
    	rh_pRH = 100; }
    if (rh_pRH < 0){
    	rh_pRH = 0; }

    *t = t_degC;
    *rh = rh_pRH;
}

void LTR329_Init()
{
    uint8_t data;

    // Activate the sensor
    data = LTR329_ACTIVE_MODE;
    HAL_I2C_Mem_Write(&hi2c3, LTR329_I2C_ADDRESS, LTR329_ALS_CONTR, I2C_MEMADD_SIZE_8BIT, &data, 1, 100);

    // Set measurement rate
    data = LTR329_MEAS_RATE;
    HAL_I2C_Mem_Write(&hi2c3, LTR329_I2C_ADDRESS, LTR329_ALS_MEAS_RATE, I2C_MEMADD_SIZE_8BIT, &data, 1, 100);
}
void LTR329_Read(uint8_t *data)
{
    //uint8_t data[4];
    // Read 4 bytes of data starting from LTR329_ALS_DATA_CH1_0
    HAL_I2C_Mem_Read(&hi2c3, LTR329_I2C_ADDRESS, LTR329_ALS_DATA_CH1_0, I2C_MEMADD_SIZE_8BIT, data, 4, 100);

    // Combine bytes to get the light data for each channel
    //*ch1 = (uint16_t)(data[1] << 8) | data[0];
    //*ch0 = (uint16_t)(data[3] << 8) | data[2];

}

void Forward(){
	//B1
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_1, GPIO_PIN_SET);
	HAL_Delay(2000);
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_1, GPIO_PIN_RESET);
}
void Right(){
	//B5
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_5, GPIO_PIN_SET);
	HAL_Delay(330);
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_5, GPIO_PIN_RESET);
}
void Left(){
	//B3
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_3, GPIO_PIN_SET);
	HAL_Delay(340);
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_3, GPIO_PIN_RESET);
}
void Navigation(int destinationX, int destinationY){
    char message[20];  // Create a character array to hold the message

	int deltaX = destinationX - Coordinaat[0];
	int deltaY = destinationY - Coordinaat[1];
	while( deltaX != 0){
	if (deltaX > 0){
		if(direction[0] == 0){
			if(direction[1] == 1){
				Right();
				direction[0] = 1;
				direction[1] = 0;
			  //  sprintf(message, "0 draai rechts\r\n");

			    // Send the message over UART
			   // SendUARTMessage(message);

			}else {
				Left();
				direction[0] = 1;
				direction[1] = 0;
			   // sprintf(message, "0 draai links\r\n");

			    // Send the message over UART
			   // SendUARTMessage(message);
			}

		}else{
			if(direction[1] ==-1 ){
				Left();
				Left();
				direction[0] = 1;
				direction[1] = 0;
			    //sprintf(message, "0 2x links\r\n");

			    // Send the message over UART
			    //SendUARTMessage(message);
			}
		}
	}
	else if (deltaX < 0){
		if(direction[0] == 0){
			if(direction[1] == 1){
				Left();
				direction[0] = -1;
				direction[1] = 0;
			    //sprintf(message, "1 draai links\r\n");
			    //SendUARTMessage(message);


			}else {
				Right();
				direction[0] = -1;
				direction[1] = 0;
			    //sprintf(message, "1 draai rechts\r\n");
			    //SendUARTMessage(message);

			}

		}else{
			if(direction[1] ==1 ){
				Left();
				Left();
				direction[0] = -1;
				direction[1] = 0;
			    //sprintf(message, "1 2xlinks\r\n");
			    //SendUARTMessage(message);

			}
		}
	}

	for(int i = 0; i < abs(deltaX); i++){
		Forward();
		Coordinaat[0] += direction[0];
	    sprintf(message, "forward X %d %d\r\n", Coordinaat[0], Coordinaat[1]);

	    // Send the message over UART
	    //SendUARTMessage(message);
	}

	deltaX = destinationX - Coordinaat[0];
	}
	while(deltaY != 0){
		if(deltaY > 0){
			if (direction[0] == 1){
				Left();
				direction[0] = 0;
				direction[1] = 1;
				///sprintf(message, "Y draai links\r\n");
				//SendUARTMessage(message);

			} else if (direction[0] == -1){
				Right();
				direction[0] = 0;
				direction[1] = 1;
				//sprintf(message, "Y draai rechts\r\n");
				//SendUARTMessage(message);

			}else{
				if (direction[1] == -1){
					Right();
					Right();
					direction[0] = 0;
					direction[1] = 1;
					//sprintf(message, "Y 2xrechts\r\n");
					//SendUARTMessage(message);
				}
			}

		}
		if(deltaY < 0){
			if (direction[0] == 1){
				Right();
				direction[0] = 0;
				direction[1] = -1;
				///sprintf(message, "Y draai links\r\n");
				//SendUARTMessage(message);

			} else if (direction[0] == -1){
				Left();
				direction[0] = 0;
				direction[1] = -1;
				//sprintf(message, "Y draai rechts\r\n");
				//SendUARTMessage(message);

			}else{
				if (direction[1] == 1){
					Right();
					Right();
					direction[0] = 0;
					direction[1] = -1;
					//sprintf(message, "Y 2xrechts\r\n");
					//SendUARTMessage(message);
				}
			}

		}
		for(int i = 0; i < abs(deltaY); i++){
			Forward();
			Coordinaat[1] += direction[1];
			sprintf(message, "forward Y %d %d\r\n", Coordinaat[0], Coordinaat[1]);

			// Send the message over UART
			// SendUARTMessage(message);
		}
		deltaY = destinationY - Coordinaat[1];

	}
}

void enter_sleep_mode(void) {
    // Enter Sleep mode with WFI instruction and main regulator ON
    HAL_PWR_EnterSLEEPMode(PWR_MAINREGULATOR_ON, PWR_SLEEPENTRY_WFI);
}
void wake_up_robot(void) {
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_6, GPIO_PIN_SET);
	HAL_Delay(2000);
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_6, GPIO_PIN_RESET);
}


/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */
	  float t, rh;
	  uint8_t data[4];
	  uint16_t ch0, ch1;
	  int x=0,y=0;
  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_USART2_UART_Init();
  MX_I2C3_Init();
  /* USER CODE BEGIN 2 */

  HAL_PWREx_EnableLowPowerRunMode();

  //HAL_NVIC_SetPriority(USART2_IRQn, 0, 0);
  //HAL_NVIC_EnableIRQ(USART2_IRQn);
  //__HAL_UART_ENABLE_IT(&huart2, UART_IT_RXNE);
  SHT40_Init();
  LTR329_Init();
  HAL_UART_Receive_IT (&huart2, &UART2_rxBuffer, 4);

  //enter_sleep_mode();
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
	  if (rx_flag)
	  {
		  rx_flag = RESET;
		  uint8_t payload[30];
		  uint8_t n;
		  char send_type = UART2_rxBuffer[0];
		  int x_coord = UART2_rxBuffer[1];
		  int y_coord = UART2_rxBuffer[2];
		  Navigation(x_coord,y_coord);
		  switch (send_type) {
			case 'T':
				SHT40_Read(&t, &rh, SHT40_MEAS_HIGH_PRECISION);
				message m1 = {.end_msg_char = 'e', .x = x_coord, .y = y_coord, .msg_type = send_type, .msg_data.temperature = t};
				n = create_payload(m1, payload);
				break;
			case 'H':
				SHT40_Read(&t, &rh, SHT40_MEAS_HIGH_PRECISION);
				message m2 = {.end_msg_char = 'e', .x = x_coord, .y = y_coord, .msg_type = send_type, .msg_data.humidity = rh};
				n = create_payload(m2, payload);
				break;
			case 'L':
				LTR329_Read(data);
				message m3 = {.end_msg_char = 'e', .x = x_coord, .y = y_coord, .msg_type = send_type, .msg_data.light = *data};
				n = create_payload(m3, payload);
				break;
			default:
				break;
		}
		  HAL_UART_Transmit(&huart2, payload, n, 10);
	  }
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  if (HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure LSE Drive Capability
  */
  HAL_PWR_EnableBkUpAccess();
  __HAL_RCC_LSEDRIVE_CONFIG(RCC_LSEDRIVE_LOW);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_LSE|RCC_OSCILLATORTYPE_MSI;
  RCC_OscInitStruct.LSEState = RCC_LSE_ON;
  RCC_OscInitStruct.MSIState = RCC_MSI_ON;
  RCC_OscInitStruct.MSICalibrationValue = 0;
  RCC_OscInitStruct.MSIClockRange = RCC_MSIRANGE_10;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_MSI;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Enable MSI Auto calibration
  */
  HAL_RCCEx_EnableMSIPLLMode();
}

/**
  * @brief I2C3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C3_Init(void)
{

  /* USER CODE BEGIN I2C3_Init 0 */

  /* USER CODE END I2C3_Init 0 */

  /* USER CODE BEGIN I2C3_Init 1 */

  /* USER CODE END I2C3_Init 1 */
  hi2c3.Instance = I2C3;
  hi2c3.Init.Timing = 0x00707CBB;
  hi2c3.Init.OwnAddress1 = 0;
  hi2c3.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c3.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c3.Init.OwnAddress2 = 0;
  hi2c3.Init.OwnAddress2Masks = I2C_OA2_NOMASK;
  hi2c3.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c3.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c3) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Analogue filter
  */
  if (HAL_I2CEx_ConfigAnalogFilter(&hi2c3, I2C_ANALOGFILTER_ENABLE) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Digital filter
  */
  if (HAL_I2CEx_ConfigDigitalFilter(&hi2c3, 0) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C3_Init 2 */

  /* USER CODE END I2C3_Init 2 */

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  huart2.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart2.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
/* USER CODE BEGIN MX_GPIO_Init_1 */
/* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_6, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_1|GPIO_PIN_3|GPIO_PIN_5, GPIO_PIN_RESET);

  /*Configure GPIO pin : PA6 */
  GPIO_InitStruct.Pin = GPIO_PIN_6;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : PB1 PB3 PB5 */
  GPIO_InitStruct.Pin = GPIO_PIN_1|GPIO_PIN_3|GPIO_PIN_5;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

/* USER CODE BEGIN MX_GPIO_Init_2 */
/* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
	if ((UART2_rxBuffer[0] == 'T' || UART2_rxBuffer[0]  == 'L' || UART2_rxBuffer[0]  == 'H') && UART2_rxBuffer[sizeof(UART2_rxBuffer)-1]  == 'e')
	{
		rx_flag = SET;
		/*
		UART2_rxBuffer = 0;
		send_type = 'T';
		*/
	}
	/*
	else if (UART2_rxBuffer[0]  == 'L')
	{
		rx_flag = SET;
		UART2_rxBuffer = 0;
		send_type = 'L';
	}
	else if (UART2_rxBuffer[0]  == 'H')
	{
		rx_flag = SET;
		UART2_rxBuffer = 0;
		send_type = 'H';
	}
	*/
	HAL_UART_Receive_IT (&huart2, &UART2_rxBuffer, 4);
}

uint8_t create_payload(message msg, uint8_t *payload)
{
    uint8_t payload_i = 0;

    memcpy(payload+payload_i, &msg.msg_type, sizeof(msg.msg_type));
    payload_i += sizeof(msg.msg_type);
    memcpy(payload+payload_i, &msg.x, sizeof(msg.x));
    payload_i += sizeof(msg.x);
    memcpy(payload+payload_i, &msg.y, sizeof(msg.y));
    payload_i += sizeof(msg.y);
    if (msg.msg_type == 'T')
    {
        memcpy(payload+payload_i, &msg.msg_data.temperature, sizeof(msg.msg_data.temperature));
        payload_i += sizeof(msg.msg_data.temperature);
    }
    else if (msg.msg_type == 'H')
    {
        memcpy(payload+payload_i, &msg.msg_data.humidity, sizeof(msg.msg_data.humidity));
        payload_i += sizeof(msg.msg_data.humidity);
    }
    else if (msg.msg_type == 'L')
	{
		memcpy(payload+payload_i, &msg.msg_data.light, sizeof(msg.msg_data.light));
		payload_i += sizeof(msg.msg_data.light);
	}

    payload[payload_i++] = msg.end_msg_char;

    return payload_i;
}

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
