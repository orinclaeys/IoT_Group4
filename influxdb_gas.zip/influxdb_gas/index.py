import http.server

from http import HTTPStatus

import socketserver

import json

import influx_db_gateway



class HttpHandler(http.server.SimpleHTTPRequestHandler):

    def do_GET(self):

        self.send_response(HTTPStatus.OK)

        self.send_header('Content-type', 'application/json')

        self.end_headers()



        db_gateway = influx_db_gateway.InfluxDbGateway()

        result = db_gateway.query_data()



        self.wfile.write(bytes(json.dumps(result, indent=2) + "\n", "utf8"))



    def do_POST(self):

        content_length = int(self.headers['Content-Length'])

        post_data = self.rfile.read(content_length)



        data_points = json.loads(post_data)



        self.send_response(HTTPStatus.OK)

        self.send_header('Content-type', 'application/json')

        self.end_headers()



        db_gateway = influx_db_gateway.InfluxDbGateway()

        result = db_gateway.insert_data(data_points)



        self.wfile.write(bytes(json.dumps(result, indent=2) + "\n", "utf8"))



httpd = socketserver.TCPServer(('', 8082), HttpHandler)

print("Web server is now running on port 8082...")



try:

    httpd.serve_forever()

except KeyboardInterrupt:

    httpd.server_close()

    print("The HTTP server has stopped running.")