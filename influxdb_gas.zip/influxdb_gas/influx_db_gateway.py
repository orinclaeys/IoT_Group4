from influxdb import InfluxDBClient



class InfluxDbGateway:

    def db_conn(self):

        client = InfluxDBClient(

            'localhost',

            8086,

            'admin',

            'gasbusterspass',

            'gasbusters_coord_db'

            #'gasbust_db'

        )

        return client



    def query_data(self):

        inf_db_client = self.db_conn()

        #result = inf_db_client.query('SELECT "type", "value" FROM "gasbusters_measurements"')

        result = inf_db_client.query('SELECT "type","x","y","value" FROM "gasbusters_measurements"')

        return list(result)





    def insert_data(self, data_points):

        data_type = data_points['type']

        data_value = data_points['value']

        x_coord = data_points['x']

        y_coord = data_points['y']

        inf_db_client = self.db_conn()

        inf_db_client.write_points([

            {

                "measurement": "gasbusters_measurements",

                "tags": {"type": data_type},
                #added x and y for new database
                "fields": {"x": x_coord, "y": y_coord, "value": data_value}

            }

        ])

        return ['success']