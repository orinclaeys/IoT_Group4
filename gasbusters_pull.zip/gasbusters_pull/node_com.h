#ifndef __NODE_COM_H__
#define __NODE_COM_H__

/* ---------------------------------------------------------------------- */

#include <stdbool.h>
#include <stdint.h>

/* ---------------------------------------------------------------------- */

#define START_MSG_CHARACTER 's'
#define END_MSG_CHARACTER 'e'

#define BUFFER_SIZE 30

/* ---------------------------------------------------------------------- */

union msg_data_u {
    float temperature;
};

typedef struct {
    //const char start_msg_char;
    //enum msg_type_e msg_type;
    const char msg_type;
    union msg_data_u msg_data;
    const char end_msg_char;
} __attribute__((packed)) message;

/* ---------------------------------------------------------------------- */

extern volatile uint8_t uart_rx_buffer[BUFFER_SIZE];
extern volatile bool uart_rx_done_flag;

/* ---------------------------------------------------------------------- */

uint8_t create_payload(message msg, uint8_t* payload);
void uart_rx_buffer_handler(uint8_t input_byte);

/* ---------------------------------------------------------------------- */

#endif /* __NODE_COM_H__ */
