/*
 * Copyright (c) 2015-2021 University of Antwerp, Aloxy NV.
 *
 * This file is part of Sub-IoT.
 * See https://github.com/Sub-IoT/Sub-IoT-Stack for further info.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */


// This examples does not push sensor data to gateway(s) continuously, but instead writes the sensor value to a local file,
// which can then be fetched on request.
// Temperature data is used as a sensor value, when a HTS221 is available, otherwise value 0 is used.
// Contrary to the sensor_push example we are now defining an Access Profile which has a periodic scan automation enabled.
// The sensor will sniff the channel every second for background adhoc synchronization frames, to be able to receive requests from other nodes.

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "hwleds.h"
#include "hwsystem.h"
#include "hwlcd.h"

#include "scheduler.h"
#include "timer.h"
#include "debug.h"
#include "d7ap_fs.h"
#include "log.h"
#include "compress.h"

#include "d7ap.h"
#include "alp_layer.h"
#include "dae.h"
#include "platform_defs.h"
#include "modules_defs.h"
#include "platform.h"
#include "hwuart.h"
#include "node_com.h"
#include "misc.h"

/*
#ifdef USE_HTS221
  #include "HTS221_Driver.h"
  #include "hwi2c.h"
#endif

#ifdef MODULE_LORAWAN
  #error "sensor_pull app is not compatible with LoRaWAN, so disable MODULE_LORAWAN in cmake"
#endif

#if !defined(USE_SX127X) && !defined(USE_NETDEV_DRIVER)
  #error "background frames are only supported by the sx127x driver for now"
#endif
*/

#define TASK_FILE_ID             0x30
#define SENSOR_FILE_ID           0x20
#define SENSOR_FILE_SIZE         7
#define TASK_FILE_SIZE           3
#define SENSOR_INTERVAL_SEC	TIMER_TICKS_PER_SEC * 5

#ifdef USE_HTS221
  static i2c_handle_t* hts221_handle;
#endif

static uart_handle_t* uart_handle;
//unsigned char request_type;
volatile bool uart_flag = false;

void callback_uart_rx(uart_handle_t* uart_handler, uint8_t byte);

// Define the D7 interface configuration used for sending the ALP command on

static alp_interface_config_d7ap_t itf_config = (alp_interface_config_d7ap_t){
  .itf_id = ALP_ITF_ID_D7ASP,
  .d7ap_session_config = {
    .qos = {
        .qos_resp_mode = SESSION_RESP_MODE_PREFERRED,
        .qos_retry_mode = SESSION_RETRY_MODE_NO
    },
    .dormant_timeout = 0,
    .addressee = {
        .ctrl = {
            .nls_method = AES_NONE,
            .id_type = ID_TYPE_NOID,
        },
        .access_class = 0x01,
        .id = { 0 }
    }
  }
};

/*
void execute_sensor_measurement()
{
  static int16_t temperature = 0; // in decicelsius. When there is no sensor, we transmit a rising number

#if defined USE_HTS221
  i2c_acquire(hts221_handle);
  HTS221_Get_Temperature(hts221_handle, &temperature);
  i2c_release(hts221_handle);
#else
  temperature++;
#endif

  temperature = __builtin_bswap16(temperature); // need to store in big endian in fs
  //int rc = d7ap_fs_write_file(SENSOR_FILE_ID, 0, (uint8_t*)&temperature, SENSOR_FILE_SIZE, ROOT_AUTH);
  //assert(rc == 0);
  temperature = __builtin_bswap16(temperature); // revert to make sure we're working with the right value

  //timer_post_task_delay(&execute_sensor_measurement, SENSOR_INTERVAL_SEC);
    // alloc command. This will be freed when the command completes
  alp_command_t* command = alp_layer_command_alloc(false, false);
  
  // forward to the D7 interface
  alp_append_forward_action(command, (alp_interface_config_t*)&itf_config, d7ap_session_config_length(&itf_config.d7ap_session_config));

  // add the return file data action
  //alp_append_return_file_data_action(command, SENSOR_FILE_ID, 0, SENSOR_FILE_SIZE, (uint8_t*)&temperature);
  alp_append_return_file_data_action(command, SENSOR_FILE_ID, 0, SENSOR_FILE_SIZE, (uint8_t*)data_to_send);
  // and finally execute this
  alp_layer_process(command);
}
*/
/*
void execute_sensor_measurement()
{
  //uart_send_string(uart_handle, "uart test");
  //uart_send_string(uart_handle, "exec");
  if (uart_flag)
  {
    //uart_send_string(uart_handle, "send");
    uart_flag = false;
    // Generate ALP command.
    // We will be sending a return file data action, without a preceding file read request.
    // This is an unsolicited message, where we push the sensor data to the gateway(s).
    
    // alloc command. This will be freed when the command completes
    alp_command_t* command = alp_layer_command_alloc(false, false);
    
    // forward to the D7 interface
    alp_append_forward_action(command, (alp_interface_config_t*)&itf_config, d7ap_session_config_length(&itf_config.d7ap_session_config));

    // add the return file data action
    //alp_append_return_file_data_action(command, SENSOR_FILE_ID, 0, SENSOR_FILE_SIZE, (uint8_t*)&temperature);
    alp_append_return_file_data_action(command, SENSOR_FILE_ID, 0, SENSOR_FILE_SIZE, (uint8_t*)data_to_send);
    // and finally execute this
    alp_layer_process(command);
  }
  else
  {
    timer_post_task_delay(&execute_sensor_measurement, SENSOR_INTERVAL_SEC);
  }
}
*/

static void file_modified_callback(uint8_t file_id)
{
    uint8_t request[4];
    log_print_string("file modified callback");
    uint32_t length = 3;
    d7ap_fs_read_file(TASK_FILE_ID, 0, request, &length, ROOT_AUTH);
    request[3] = 'e';
    uart_send_bytes(uart_handle, request, 4);
}

void init_user_files()
{
  d7ap_fs_file_header_t task_file_header = (d7ap_fs_file_header_t) {
      .file_permissions = (file_permission_t) { .user_read = true, .guest_read = true, .user_write = true, .guest_write = true},
      .file_properties.action_protocol_enabled = 0,
      .file_properties.storage_class = FS_STORAGE_PERMANENT,
      .length = TASK_FILE_SIZE ,
      .allocated_length = TASK_FILE_SIZE ,
  };

  d7ap_fs_init_file(TASK_FILE_ID, &task_file_header, NULL);

  // register a callback for when the sensor file is modified
  d7ap_fs_register_file_modified_callback(TASK_FILE_ID, &file_modified_callback);
}

void bootstrap()
{
    log_print_string("Device booted\n");
    alp_layer_init(NULL, false);
    //alp_layer_init(NULL, false);
    
    d7ap_fs_write_dll_conf_active_access_class(0x11); // use scanning AC, visible in d7ap_fs_data.c
    init_user_files();


#if defined USE_HTS221
    hts221_handle = i2c_init(0, 0, 100000, true);
    i2c_acquire(hts221_handle);
    HTS221_DeActivate(hts221_handle);
    HTS221_Set_BduMode(hts221_handle, HTS221_ENABLE);
    HTS221_Set_Odr(hts221_handle, HTS221_ODR_7HZ);
    HTS221_Activate(hts221_handle);
    i2c_release(hts221_handle);
#endif
    uart_handle = uart_init(0, 115200, 0);

    uart_set_rx_interrupt_callback(uart_handle, callback_uart_rx); //when interrupt happens, call the callback function
    uart_rx_interrupt_enable(uart_handle);

    //sched_register_task(&execute_sensor_measurement);
    //sched_post_task(&execute_sensor_measurement);
}


void callback_uart_rx(uart_handle_t* uart_handler, uint8_t byte)
{
    uart_rx_buffer_handler(byte);
    if (uart_rx_done_flag)
    {
      uint8_t data_to_send[7];
      //uart_send_string(uart_handle, "rx done");
      const char msg_type = uart_rx_buffer[0]; //find the message type based on the first char

      if (msg_type == 'T' || msg_type == 'H' || msg_type == 'L')
      {
        memcpy(data_to_send, (uint8_t *) (uart_rx_buffer+1), sizeof(uint8_t));
        
        memcpy(data_to_send+1, (uint8_t *) (uart_rx_buffer+2), sizeof(uint8_t));
        
        memcpy(data_to_send+2, (uint8_t *) (uart_rx_buffer+3), sizeof(float));
      }
      data_to_send[6] = msg_type;
      //uart_send_bytes(uart_handle,data_to_send, 7);
      /*
      // alloc command. This will be freed when the command completes
      alp_command_t* command = alp_layer_command_alloc(false, false);
      
      // forward to the D7 interface
      alp_append_forward_action(command, (alp_interface_config_t*)&itf_config, d7ap_session_config_length(&itf_config.d7ap_session_config));

      // add the return file data action
      //alp_append_return_file_data_action(command, SENSOR_FILE_ID, 0, SENSOR_FILE_SIZE, (uint8_t*)&temperature);
      alp_append_return_file_data_action(command, SENSOR_FILE_ID, 0, SENSOR_FILE_SIZE, (uint8_t*)data_to_send);
      // and finally execute this
      alp_layer_process(command);
      */
      //uart_flag = true;
      // alloc command. This will be freed when the command completes
      alp_command_t* command = alp_layer_command_alloc(false, false);
      
      // forward to the D7 interface
      alp_append_forward_action(command, (alp_interface_config_t*)&itf_config, d7ap_session_config_length(&itf_config.d7ap_session_config));

      // add the return file data action
      //alp_append_return_file_data_action(command, SENSOR_FILE_ID, 0, SENSOR_FILE_SIZE, (uint8_t*)&temperature);
      alp_append_return_file_data_action(command, SENSOR_FILE_ID, 0, SENSOR_FILE_SIZE, data_to_send);
      // and finally execute this
      alp_layer_process(command);
    }
}
