#include "node_com.h"

#include <string.h>

/* ---------------------------------------------------------------------- */

volatile uint8_t uart_rx_buffer[BUFFER_SIZE];
static volatile uint8_t uart_rx_buffer_i = 0;
volatile bool uart_rx_done_flag;

/* ---------------------------------------------------------------------- */

//necessary when sending from stm to dash7 node
//not used the other way, because we send only one char as a request
/*
uint8_t create_payload(message msg, uint8_t *payload)
{
    uint8_t payload_i = 0;

    memcpy(payload+payload_i, &msg.msg_type, sizeof(msg.msg_type));
    payload_i += sizeof(msg.msg_type);

    if (msg.msg_type == 'T')
    {
        memcpy(payload+payload_i, &msg.msg_data.temperature, sizeof(msg.msg_data.temperature));
        payload_i += sizeof(msg.msg_data.temperature);
    }

    payload[payload_i++] = msg.end_msg_char;

    return payload_i;
}
*/
/* ---------------------------------------------------------------------- */

void uart_rx_buffer_handler(uint8_t input_byte)
{
    uart_rx_done_flag = false;

    if (input_byte == 'T' || input_byte == 'H' || input_byte == 'L') //T right now, or other starter chars, depending on the message
    {
      uart_rx_buffer_i = 0;
    }
    else if (input_byte == 'e') //end of message
    {
      uart_rx_done_flag = true;
    }

    //fill buffer
    uart_rx_buffer[uart_rx_buffer_i] = input_byte;

    if (uart_rx_buffer_i < (BUFFER_SIZE - 1))
    {
      uart_rx_buffer_i++;
    }
}
