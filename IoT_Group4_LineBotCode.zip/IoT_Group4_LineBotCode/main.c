#include "hwconfig.h"

#include "FreeRTOS.h"
#include "task.h"
#include <avr/io.h>
#include <avr/interrupt.h>

#include "DriverSysClk.h"

#include "StartupTask.h"
#include "DriverMotor.h"
#include "DriverPower.h"
#include <util/delay.h>

#include "queue.h"
#include "semphr.h"
#include "trace.h"

#include <avr/sleep.h>
#include <avr/power.h>

#include <stdio.h>
#include <stdlib.h>

uint8_t *ucHeap;

ISR(PORTA_INT0_vect){
	
}
void enterSleepMode(void) {
	// Set the sleep mode. For XMEGA, you might use SLEEP_SMODE_PDOWN_gc for power down.
	// Check the specific group configuration (gc) value for your microcontroller.
	//PMIC.CTRL = 0b111;

	set_sleep_mode(SLEEP_SMODE_PDOWN_gc);

	// Disable any peripherals here to save power.
	// For example, power_adc_disable(); (if such function exists or equivalent)

	// Enable global interrupts so that the MCU can wake up from an interrupt.
	sei();
	
	//vTaskDelay(10);
	// Enable sleep.
	
	
	//PMIC.CTRL &=0b11111100; // shut off medium and low lever interrupt
	//DriverPowerVccAuxSet(0);
	//vTaskDelay(2);
	sleep_enable();
	sleep_mode();
	
	sleep_disable();
	//vTaskDelay(75);
	// Enter sleep mode.
	//sleep_cpu();

	// Sleep mode will be exited upon receiving an interrupt.
	//vTaskDelay(50);
	// Disable sleep after waking up.
	//sleep_disable();
}

int main(void)
{
	DriverSysClkXtalInit();	//Clock init
	//Allocate FreeRTOS heap
	ucHeap=malloc(configTOTAL_HEAP_SIZE);
	if (ucHeap==NULL) while(1);
	
	//Enable interrupts
	PMIC.CTRL=0b111;		
	sei();
	
	//Init startup task
	InitStartupTask();
	DriverMotorInit();
	DriverPowerVccAuxSet(1);
	//PORTE.DIR = 0b11111111;
	
	PORTA.DIR &= ~(1 << 5); // Set PA5 as input    
	PORTA.PIN5CTRL = PORT_ISC_BOTHEDGES_gc; // Trigger on both edges     
	// Enable pin change interrupt for PA5    
	PORTA.INT0MASK = (1 << 5);     // Set interrupt priority    
	PORTA.INTCTRL = (PORTA.INTCTRL & ~PORT_INT0LVL_gm) | PORT_INT0LVL_MED_gc;
	
	PORTE.DIR = 0b00000000;
	PORTE.PIN2CTRL = 0b00010000;
	PORTE.PIN3CTRL = 0b00010000;
	PORTC.DIR = 0b00000000;
	PORTC.PIN3CTRL = 0b00010000;
	while(1){
		if((PORTE.IN & 0b00000100) == 0b00000100){ //CHECK T5
			DriverMotorSet(4000,3995);
		}else if((PORTE.IN & 0b00001000) == 0b00001000){ //CHECK T6
			DriverMotorSet(4000,-4000);
		}else if((PORTC.IN & 0b0001000) == 0b00001000){ //CHECK T4
			DriverMotorSet(-4000,4000);
		}else{
			//enterSleepMode();
			DriverMotorSet(0,0);
			//enterSleepMode();
		}
	}
	return 0;
}


