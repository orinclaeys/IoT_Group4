#ifndef MEMMAP_H
#define MEMMAP_H
#include <stdint.h>



void MemMap();

#endif